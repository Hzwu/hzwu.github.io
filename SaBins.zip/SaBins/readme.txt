*****

The provided files contain part of the source code.

Since the code depends on Fairseq, we suggest downloading code from Fairseq official github and then replacing the file with the provided one in the same name.

Complete source code is available after the replacement.

*****

All the requirements and installation refer to Fairseq.

Steganographic text can be generated according to the command about "fairseq-generate".

Fairseq github: https://github.com/facebookresearch/fairseq

Fairseq tutorial: https://fairseq.readthedocs.io/en/latest/